import webbrowser
import os
fileloc= os.path.abspath(__file__)
cwd= os.path.dirname(fileloc)
webbrowser.open(cwd+"/index.html")