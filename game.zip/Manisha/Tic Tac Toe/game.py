import webbrowser
webbrowser.open("https://tic-tac-toe-fkil.onrender.com",new=0)
