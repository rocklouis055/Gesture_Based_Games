from tkinter import *
import subprocess
import os
import tkinter.font as tkFont
import webbrowser
import re
w=1280
h=720

def run(w):
    w.loop()

def init():
    global window
    window=Tk()
    obj=page(window)
    
    obj.addgame("Temp Run 2 - Louise","Louise Patra/Temple Run 2/")
    obj.addgame("Hill Climb - Louise","Louise Patra/Hill Climbing/")
    obj.addgame("Angry Birds - Louise","Louise Patra/Angry Birds/")
    obj.addgame("Tic Tac Toe - Louise","Louise Patra/Tic Tac Toe/")
    obj.addgame("Rock Paper Scissor - Manisha","Manisha/Rock Paper Scissor/")
    obj.addgame("Fruit Ninja - Manisha","Manisha/Fruit Ninja/")
    obj.addgame("Tic Tac Toe- Manisha","Manisha/Tic Tac Toe/")
    obj.addgame("Fox Run - Hands - Sunil","Sunil/Fox Run/Hands/")
    obj.addgame("Fox Run - Pose - Sunil","Sunil/Fox Run/Pose/")
    obj.addgame("Ping Pong - Sunil","Sunil/Ping Pong/")
    obj.addgame("Subway Surfers - Old","Old/Subway Surfers/")
    obj.addgame("Subway Surfers - Kamaljeet","Kamaljeet/Subway Surfers/")
    
    window.geometry(str(w)+"x"+str(h))
    window.title("Welcome")
    hu = Label(window, text="Hello User :D",font=('Helvetica bold', 24)).place(relx=0.5, rely=0.25, anchor="center")
    button = Button(window,width=20,font=('Helvetica bold', 24),text="GET Started?", command=obj.run).place(relx=0.5, rely=0.55, anchor="center")
    window.bind_all('<Escape>', lambda x:window.destroy())
    window.protocol("WM_DELETE_WINDOW",lambda :window.destroy())
    # window.resizable(False,False)
    window.mainloop()
    
class page:
    def __init__(self,prevwin):
        self.window=Toplevel(prevwin)
        self.window.geometry(str(w)+"x"+str(h))
        self.window.title("GAMES")
        self.i=0
        Label(self.window, text="Select one game to play :",font=('Helvetica bold', 24)).place(relx=0.5, rely=0.1, anchor="center")
        self.window.bind_all('<Escape>', lambda x:self.quit())
        self.window.protocol("WM_DELETE_WINDOW",lambda :self.quit())
        # self.window.resizable(False,False)
        self.window.withdraw()
        self.prevwin=prevwin
    def run(self):
        self.window.deiconify()
        self.prevwin.withdraw()
    def quit(self):
        self.prevwin.destroy()
    def addgame(self,name,folder,typ=0):
        self.i+=1
        game(self.prevwin,self.window,name,self.i,folder,typ)
        
class game:
    def __init__(self,main,prevwin,name,n,folder,typ=0):
        self.name=name
        self.prevwin=prevwin
        self.main=main
        self.type=typ
        self.file=folder+"game.py"
        self.pid=None
        self.folder=folder
        self.about=self.readfile("about.txt")
        self.reqtext=self.readfile("req.txt")
        Button(self.prevwin,width=28,font=('Helvetica bold', 15),bd=5, padx=5, pady=5,text=str(n)+". "+name, command=self.start).place(relx=0.5, rely=0.04+0.07*(n+1), anchor="center")
    def start(self):
        self.window=Toplevel(self.main)
        self.window.geometry(str(w)+"x"+str(h))
        self.window.title(self.name)
        self.window.bind_all('<Escape>', lambda x:self.quit())
        self.window.protocol("WM_DELETE_WINDOW",lambda :self.quit())
        Button(self.window,activebackground="#12218A", bg="#1D37E8",activeforeground="#fff", text="Back",command=self.back,width=5, bd=5, padx=5, pady=5).place(relx=.1,rely=.1,anchor='center')
        Label(self.window, text="Click to Launch the game",font=('Helvetica bold', 24)).place(relx=0.5, rely=0.1, anchor="center")
        Button(self.window, text="Launch",command=self.launch,width=17, bd=5, padx=5, pady=5).place(relx=.4,rely=.2,anchor='center')
        if self.reqtext:
            Button(self.window, text="Instal Requirements",command=self.req,width=17, bd=5, padx=5, pady=5).place(relx=.6,rely=.2,anchor='center')
        if self.about:
            Label(self.window, text="About / Instructions",font=('Helvetica bold', 24)).place(relx=0.5, rely=0.35, anchor="center")
            frame = Frame(self.window, width=250, height=250)
            frame.place(relx=0.25, rely=0.4, relwidth=0.5, relheight=1.0)
            text = Text(frame, wrap=WORD)
            scrollbar = Scrollbar(frame)
            scrollbar.place(relx=1.0, rely=0.0, relheight=0.5, anchor=NE)
            text.place(relx=0.0, rely=0.0, relwidth=1.0, relheight=0.5)
            text.config(yscrollcommand=scrollbar.set, font=('Roboto', 12, 'bold'))
            if "*[" in self.about and "]*" in self.about:
                for i in re.split("(\*\[.*]\*)",self.about):
                    if i[0]=="*":
                        k=re.split("\((.*)\).*\((.*)\)",i)
                        # print(k[1],k[2])
                        text.insert(END, k[1],("link",k[2]))
                        text.tag_bind(k[2], "<Enter>", self.open_link)
                        text.tag_bind(k[2], "<Leave>", self.leave_link)
                        text.tag_configure(k[2], foreground="blue", underline=False)
                    else:
                        # print(i)
                        text.insert(END, i)
            else:text.insert(END, self.about)
            text.config(state=DISABLED)

        # self.window.resizable(False,False)
        self.window.withdraw()
        self.run()
    def open_link(self,event):
        link_url = event.widget.tag_names(CURRENT)[1]
        event.widget.tag_configure(link_url, foreground="blue", underline=True)
        event.widget.tag_bind(link_url, "<Button-1>", lambda event: webbrowser.open(link_url))

    def leave_link(self,event):
        link_url = event.widget.tag_names(CURRENT)[1]
        event.widget.tag_configure(link_url, underline=False)
        
    def readfile(self,file):
        try:
            with open(self.folder+file,"r") as file:
                return(file.read())
        except:
            return(None)
    def launch(self):
        if self.type==0:
            proc = subprocess.Popen(['python3', self.file], stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.PIPE,start_new_session=True)
            self.pid = proc.pid
            print(f"Running script in the background with PID {self.pid}")
    def run(self):
        self.window.deiconify()
        self.prevwin.withdraw()
    def quit(self):
        self.main.destroy()
        if self.pid!=None:
            os.kill(self.pid, 15)
            # os.kill(pid, 9)
    def back(self):
        self.window.withdraw()
        self.prevwin.deiconify()
        if self.pid!=None:
            os.kill(self.pid, 15)
            # os.kill(pid, 9)
    def req(self):
        a=Label(self.window, text="Even though its looking like its hang,\nBut its installing the requirements.",font=('Helvetica bold',10),fg="red")
        a.place(relx=0.8, rely=0.2, anchor="center")
        self.window.update()
        proc = subprocess.Popen(
        self.reqtext.split(),
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
        )
        input_lines = self.reqtext.strip().split('\n')
        input_text = '\n'.join(input_lines[:]) 
        proc.stdin.write(input_text)
        proc.stdin.close()

        while True:
            output = proc.stdout.readline()
            error = proc.stderr.readline()
            if output == '' and error == '' and proc.poll() is not None:
                break
            if output:
                print(output.strip())
            if error:
                print(error.strip())

        # Get the PID of the process
        pid = proc.pid
        print("PID:", pid)
        a.place_forget()
        
init()